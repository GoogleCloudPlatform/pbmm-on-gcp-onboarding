Extracted after deployment (0-,1-,2-,3-hub&spoke,4-) from asset inventory
There are hardcoded references to regions us-central1 and us-west1
Need to find missing parameterization.
A bug was opened w/ Google PSO: Location set in bootstrap is ignored
https://github.com/terraform-google-modules/terraform-example-foundation/issues/1172

Back-references via tfstate

Targets
Occurrences of 'data.terraform_remote_state.env' in Directory C:\Users\romma05\Documents\ZA-GCP-v3-TEF\TEF-GCP-LZ-HS with mask '*.tf*'
Found occurrences in Directory C:\Users\romma05\Documents\ZA-GCP-v3-TEF\TEF-GCP-LZ-HS with mask '*.tf*'
Unclassified
TEF-GCP-LZ-HS
3-networks-dual-svpc\envs\shared
remote.tf
  development_folder_name    = data.terraform_remote_state.env_development.outputs.env_folder
  non_production_folder_name = data.terraform_remote_state.env_non_production.outputs.env_folder
  production_folder_name     = data.terraform_remote_state.env_production.outputs.env_folder
3-networks-dual-svpc\modules\base_env
vpn.tf.example
  env_secret_project_id = data.terraform_remote_state.environments_env.outputs.env_secrets_project_id
3-networks-hub-and-spoke\envs\shared
remote.tf
  development_folder_name           = data.terraform_remote_state.env_development.outputs.env_folder
  non_production_folder_name        = data.terraform_remote_state.env_non_production.outputs.env_folder
  production_folder_name            = data.terraform_remote_state.env_production.outputs.env_folder
3-networks-hub-and-spoke\modules\base_env
vpn.tf.example
  env_secret_project_id = data.terraform_remote_state.environments_env.outputs.env_secrets_project_id
4-projects\modules\base_env
remote.tf
  env_folder_name                     = data.terraform_remote_state.environments_env.outputs.env_folder


Targets
Occurrences of 'data.terraform_remote_state.org' in Directory C:\Users\romma05\Documents\ZA-GCP-v3-TEF\TEF-GCP-LZ-HS with mask '*.tf*'
Found occurrences in Directory C:\Users\romma05\Documents\ZA-GCP-v3-TEF\TEF-GCP-LZ-HS with mask '*.tf*'
Unclassified
TEF-GCP-LZ-HS
2-environments\modules\env_baseline
remote.tf
  tags            = data.terraform_remote_state.org.outputs.tags
3-networks-dual-svpc\envs\shared
remote.tf
  dns_hub_project_id         = data.terraform_remote_state.org.outputs.dns_hub_project_id
  interconnect_project_id    = data.terraform_remote_state.org.outputs.interconnect_project_id
  common_folder_name         = data.terraform_remote_state.org.outputs.common_folder_name
  network_folder_name        = data.terraform_remote_state.org.outputs.network_folder_name
3-networks-dual-svpc\modules\base_env
interconnect.tf.example
  interconnect_project_id = data.terraform_remote_state.org.outputs.interconnect_project_id
remote.tf
  restricted_project_id        = data.terraform_remote_state.org.outputs.shared_vpc_projects[var.env].restricted_shared_vpc_project_id
  restricted_project_number    = data.terraform_remote_state.org.outputs.shared_vpc_projects[var.env].restricted_shared_vpc_project_number
  base_project_id              = data.terraform_remote_state.org.outputs.shared_vpc_projects[var.env].base_shared_vpc_project_id
  interconnect_project_number  = data.terraform_remote_state.org.outputs.interconnect_project_number
  dns_hub_project_id           = data.terraform_remote_state.org.outputs.dns_hub_project_id
3-networks-hub-and-spoke\envs\shared
remote.tf
  dns_hub_project_id                = data.terraform_remote_state.org.outputs.dns_hub_project_id
  interconnect_project_id           = data.terraform_remote_state.org.outputs.interconnect_project_id
  interconnect_project_number       = data.terraform_remote_state.org.outputs.interconnect_project_number
  common_folder_name                = data.terraform_remote_state.org.outputs.common_folder_name
  network_folder_name               = data.terraform_remote_state.org.outputs.network_folder_name
  base_net_hub_project_id           = data.terraform_remote_state.org.outputs.base_net_hub_project_id
  restricted_net_hub_project_id     = data.terraform_remote_state.org.outputs.restricted_net_hub_project_id
  restricted_net_hub_project_number = data.terraform_remote_state.org.outputs.restricted_net_hub_project_number
3-networks-hub-and-spoke\modules\base_env
remote.tf
  restricted_project_id             = data.terraform_remote_state.org.outputs.shared_vpc_projects[var.env].restricted_shared_vpc_project_id
  restricted_project_number         = data.terraform_remote_state.org.outputs.shared_vpc_projects[var.env].restricted_shared_vpc_project_number
  base_project_id                   = data.terraform_remote_state.org.outputs.shared_vpc_projects[var.env].base_shared_vpc_project_id
  dns_hub_project_id                = data.terraform_remote_state.org.outputs.dns_hub_project_id
  base_net_hub_project_id           = data.terraform_remote_state.org.outputs.base_net_hub_project_id
  restricted_net_hub_project_id     = data.terraform_remote_state.org.outputs.restricted_net_hub_project_id
  restricted_net_hub_project_number = data.terraform_remote_state.org.outputs.restricted_net_hub_project_number
4-projects\business_unit_1\shared
remote.tf
  common_folder_name                 = data.terraform_remote_state.org.outputs.common_folder_name
4-projects\business_unit_2\shared
remote.tf
  common_folder_name                 = data.terraform_remote_state.org.outputs.common_folder_name
Usage in string constants
TEF-GCP-LZ-HS
terraform-google-modules\group\google\test\setup
main.tf
  member = "serviceAccount:${data.terraform_remote_state.org.outputs.ci_gsuite_sa_email}"
  member  = "serviceAccount:${data.terraform_remote_state.org.outputs.ci_gsuite_sa_email}"